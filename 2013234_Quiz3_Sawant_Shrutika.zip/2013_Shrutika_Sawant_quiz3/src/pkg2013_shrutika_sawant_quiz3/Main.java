
package pkg2013_shrutika_sawant_quiz3;

/**
 *
 * @author shrut
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
